﻿/// <reference path="C:\Users\M1028027\documents\visual studio 2015\Projects\EmployeeService\EmployeeService\Scripts/jquery-1.10.2.min.js" />

// Function to retrieve the access token from the URL
function getAccessToken() {
    if (location.hash) {
        if (location.hash.split('access_token=')) {
            var accessToken = location.hash.split('access_token=')[1].split('&')[0];
            if (accessToken) {
                isUserRegistered(accessToken);
            }
        }
    }
}

// Function to if the user authenticated by Google has registered with our system
function isUserRegistered(accessToken) {
    $.ajax({
        url: '/api/Account/UserInfo',
        method: 'GET',
        headers: {
            'content-type': 'application/json',
            'Authorization': 'Bearer ' + accessToken
        },
        success: function (response) {
            if (response.HasRegistered) {
                localStorage.setItem("accessToken", accessToken);
                localStorage.setItem("loggedInUser", response.Email);
                window.location.href = "GetData.html";
            }
            else {
                // Pass the login provider (Facebook or Google)
                signupExternalUser(accessToken, response.LoginProvider);
            }
        }
    });
}

// Register the authenticated user in our system 
function signupExternalUser(accessToken, provider) {
    $.ajax({
        url: '/api/Account/RegisterExternal',
        method: 'POST',
        headers: {
            'content-type': 'application/json',
            'Authorization': 'Bearer ' + accessToken
        },
        success: function () {
            window.location.href = "/api/Account/ExternalLogin?provider="+provider+"&response_type=token&client_id=self&redirect_uri=http%3A%2F%2Flocalhost%3A53907%2FTemplates%2FLogIn.html&state=GerGr5JlYx4t_KpsK57GFSxVueteyBunu02xJTak5m01";
        },
        error: function (jqXHR) {
            // alert(jqXHR.responseText);
            $('#divErrorText').text(JSON.stringify(jqXHR.responseJSON.ModelState.err[1]));
            $('#divError').show('fade');
        }
    });

}